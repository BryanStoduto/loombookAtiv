package com.ConversaoLombook.lombook.conversor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LombookConversorApplication {

	public static void main(String[] args) {
		SpringApplication.run(LombookConversorApplication.class, args);
	}

}
