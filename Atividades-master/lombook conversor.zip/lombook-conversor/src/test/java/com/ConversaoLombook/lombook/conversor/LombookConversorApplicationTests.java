package com.ConversaoLombook.lombook.conversor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LombookConversorApplicationTests {

	@Test
	void contextLoads() {
	}

}
